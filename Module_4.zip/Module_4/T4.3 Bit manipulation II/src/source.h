#ifndef AALTO_MERGEBITS_H
#define AALTO_MERGEBITS_H

unsigned char mergeBits(unsigned char a, unsigned char b);

#endif