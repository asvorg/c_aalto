#ifndef AALTO_BIT_SEQUENCE_H
#define AALTO_BIT_SEQUENCE_H

#include <stdint.h>

uint8_t op_bit_get_sequence(uint32_t data, uint32_t mask);

#endif
