#ifndef AALTO_ARRAY_H
#define AALTO_ARRAY_H
int array_sum(int *array, int count);

#endif //! AALTO_ARRAY_H
