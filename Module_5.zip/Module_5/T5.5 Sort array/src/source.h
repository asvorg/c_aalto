#ifndef AALTO_SORT_H
#define AALTO_SORT_H

int compare_ascending(const void *p1, const void *p2);
void sort(int *array, int size);

#endif //! AALTO_SORT_H
