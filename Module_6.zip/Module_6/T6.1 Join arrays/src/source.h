#ifndef AALTO_JOIN_ARRAYS_H_
#define AALTO_JOIN_ARRAYS_H_

int *join_arrays(unsigned int n1, const int *a1,
				 unsigned int n2, const int *a2,
				 unsigned int n3, const int *a3);

#endif
