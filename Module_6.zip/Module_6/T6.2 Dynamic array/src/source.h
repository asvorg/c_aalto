#ifndef AALTO_DYN_ARRAY_H_
#define AALTO_DYN_ARRAY_H_

int *create_dyn_array(unsigned int n);
int *add_dyn_array(int *arr, unsigned int num, int newval);

#endif
