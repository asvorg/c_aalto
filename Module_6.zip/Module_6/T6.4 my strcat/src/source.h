#ifndef AALTO_MYSTRCAT_H_
#define AALTO_MYSTRCAT_H_

char *my_strcat(char *dest, const char *src);

#endif
