#include "queue.h"

int enqueue(struct studentqueue *q, const char *name)
{
}

int dequeue(struct studentqueue *q, char *buffer, unsigned int size)
{
}