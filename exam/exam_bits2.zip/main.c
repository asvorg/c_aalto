#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/**
 * \brief Combines one 2-bit number in argument a with a 6-bit number in argument b,
 * 		  and returns a string of a byte of which 6 left most bits are of the 
 * 		  bits of b, and 2 right most bits are the bits of a. 
 * 
 * \details This function get two binary numbers as parameters, a that has 2 bits
 * 			and b that has 6 bits. The function should combine the two numbers 
 * 			in a way that the leftmost six bits are the bits from b, and the last
 * 			two bits are the bits from a. Then, the function should write the binary
 * 			number to the given string, str.
 * 			
 * 			For example, given a = 3 (binary 11) and b = 44 (binary 101100), 
 * 			after the function is called, str should contain the string "10110011".
 * 
 * \param a A 2-bit integer (it is always masked with 0x03)
 * \param b A 6-bit integer (it is always masked with 0x3F)
 * \param str The binary string formed by combining a and b.
 * 
 * \note In your implementation, do not write to stdout to check the functionality.
 *       You should use my_tests function to print and check the functionality 
 *       of your implementation.
 */
void combine_to_string(unsigned char a, unsigned char b, char* str) {
	//TODO: implement your function here!
}

/**
 * \brief conducts the tests for your implementation.
 * 
 * \details You are strongly encouraged to test your implementation
 * using this function. Try to create at least three test cases to check
 * whether your function implementation is correct.
 * 
 */
void my_tests(void) {
	// You can write your own test code here.
}

int main(void) {
	/* You may implement your own tests in my_tests function */
	my_tests();
}
